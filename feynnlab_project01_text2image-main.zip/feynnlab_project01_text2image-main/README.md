# feynnlab_project01_text2image
This is a project and part of my internship at Feynn Labs as Machine Learning Intern

In order for the website to run, create a virtual environment using venv and activate it. Then install all necessary libraries.
First run the server "uvicorn appl:app --reload" in terminal and then in another terminal change dir to client use "npm start" to start the react app.
